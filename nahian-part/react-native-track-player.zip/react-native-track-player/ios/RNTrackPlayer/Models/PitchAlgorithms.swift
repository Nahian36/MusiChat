//
//  PitchAlgorithms.swift
//  RNTrackPlayer
//
//  Created by Anders Lemke on 28/02/2018.
//  Copyright © 2018 David Chavez. All rights reserved.
//

import Foundation

enum PitchAlgorithm: String {
    case linear, music, voice
}
