// For documentation, check our wiki
// https://github.com/react-native-kit/react-native-track-player/wiki

module.exports = require('./lib/index.js');
